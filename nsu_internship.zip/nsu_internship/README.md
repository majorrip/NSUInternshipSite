# Website Testing

Step 1: Create a database called "atifkari_cse482_internship_db" and import everything from database.sql file. Next check your db.php file for database connection configuration

```php /* for xampp mysql
//Your db.php Mysql Config
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "atifkari_cse482_internship_db";
```

Step2: Now you login as candidate with following details

```php
Email: atif@nsu.com
Password: 123456

```

Step3: Now you login as Company with following details

```php
Email: tony@stark.com
Password: 123456

```

Step4: Now you login as Admin with following details by going to nsu_internship/admin/index.php in xampp

```php
Username: admin
Password: 123456
//Note: Password is not encrpyted from code so you CAN change directly from database.
```